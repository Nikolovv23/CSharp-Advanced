﻿namespace IteratorsAndComparators
{
    public interface ICompare<T>
    {
    }
}